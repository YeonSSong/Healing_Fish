﻿#region Using statements

using System;
using UnityEngine;

#endregion

namespace Bitgem.Core
{
    public class FlagEnumAttribute : PropertyAttribute
    {
    }
}