using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShopItem 
{
    public string Name_ = "";
    public long Price_ = 0;   
        
}
